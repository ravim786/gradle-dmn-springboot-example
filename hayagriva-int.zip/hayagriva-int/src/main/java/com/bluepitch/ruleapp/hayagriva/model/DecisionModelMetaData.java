package com.bluepitch.ruleapp.hayagriva.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DecisionModelMetaData {
    private String name;
    private String packageName;
    private String resourcePath;
    private String version;
}
