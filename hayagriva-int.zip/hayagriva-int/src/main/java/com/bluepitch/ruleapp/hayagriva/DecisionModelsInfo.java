package com.bluepitch.ruleapp.hayagriva;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bluepitch.ruleapp.hayagriva.model.DecisionModelMetaData;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties(prefix = "dmns")
@PropertySource(value = "dmn-metadata.yml", factory = YamlPropertySourceFactory.class)
public class DecisionModelsInfo {

    @Getter
    @Setter
    private Map<String, List<DecisionModelMetaData>> map = new HashMap<>();

}
