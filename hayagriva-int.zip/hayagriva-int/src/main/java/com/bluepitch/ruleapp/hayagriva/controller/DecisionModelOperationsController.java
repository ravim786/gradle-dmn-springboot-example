package com.bluepitch.ruleapp.hayagriva.controller;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.bluepitch.ruleapp.hayagriva.DecisionModelsInfo;
import com.bluepitch.ruleapp.hayagriva.HayagrivaApplication;
import com.bluepitch.ruleapp.hayagriva.model.DecisionModelMetaData;

import org.kie.kogito.decision.DecisionModelMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.Getter;

@RestController
@RequestMapping("/dmnOperations")
public class DecisionModelOperationsController {

    @Autowired
    @Getter
    DecisionModelsInfo decisionModelsInfo;

    @GetMapping(path = "/communities", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<String> getCommunities() {
        return List.copyOf(decisionModelsInfo.getMap().keySet());
    }

    @GetMapping(path = "/dmns", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<DecisionModelMetaData> getDmnMetaDataByCommunity(@RequestParam String community) {
        return decisionModelsInfo.getMap().get(community);
    }

    @PostMapping(path = "/download-dmn", produces = MediaType.APPLICATION_XML_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public String getDmn(@RequestBody Map<String, String> request) {
        String dmnString = "";
        String community = request.get("community");
        String dmnName = request.get("dmnName");
        String version = request.get("version");
        try {
            List<DecisionModelMetaData> dmnList = decisionModelsInfo.getMap().get(community);
            Predicate<DecisionModelMetaData> byNameandVersion = decisionModelMetadata -> decisionModelMetadata.getName()
                    .equals(dmnName) && decisionModelMetadata.getVersion().equals(version);
            DecisionModelMetaData dmn = dmnList.stream().filter(byNameandVersion).collect(Collectors.toList()).get(0);
            dmnString = new String(org.drools.core.util.IoUtils.readBytesFromInputStream(HayagrivaApplication.class
                    .getResourceAsStream(dmn.getPackageName() + "/" + dmn.getName() + ".dmn")));
        } catch (Exception e) {
            ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        return dmnString;
    }

}
