
import { httpDMN } from './http-common';

class dmnDataService {
    getAllServices = () => {
        return fetch("./dummyFlow.json",{
            headers : { 
              'Content-Type': 'application/json',
              'Accept': 'application/json'
             }
          })
        .then((response) => {
            return response.json();
        })
        .then((jsonData)=>{
            const homeData = jsonData.home;
            return homeData;
            //elementsList.push(homeData);
        })
        .catch((error)=>{
            console.log(error);
        })
    }
    
    getData(name){
        return httpDMN.get("/"+decodeURI(name))
    }
    
}

export default new dmnDataService();