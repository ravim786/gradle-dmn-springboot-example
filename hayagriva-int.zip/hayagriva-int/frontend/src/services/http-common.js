import axios from "axios";


export const httpDMN = axios.create({
  baseURL: "http://localhost:7070",
  headers: {
    "Content-type": "application/xml;charset=UTF-8"
  }
});

export const http = axios.create({
    baseURL: "http://localhost:7070",
    headers: {
      "Content-type": "application/json"
    }
  });