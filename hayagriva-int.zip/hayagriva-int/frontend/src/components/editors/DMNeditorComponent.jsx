import React, {useRef, useEffect, useState} from 'react';
import { fade, makeStyles } from '@material-ui/core/styles';
import { AppBar, Toolbar, Button, InputBase } from '@material-ui/core';
import { useParams } from "react-router-dom";

import UndoButton from "../buttons/UndoButton";
import RedoButton from "../buttons/RedoButton";
import DownloadButton from "../buttons/DownloadButton";
import NavbarComponent from '../NavbarComponent';
import dmnDataService from '../../services/dmnService';

import * as DmnEditor from "@kogito-tooling/kie-editors-standalone/dist/dmn";

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },

    menuButton: {
        marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 1,
    },
    fileNameField:{
        backgroundColor: fade(theme.palette.common.white, 0.05),
        '&:hover': {
            backgroundColor: fade(theme.palette.common.white, 0.10),
        }
    },
    fileNameInput:{
        color: "inherit",
        padding: theme.spacing(1, 1, 1, 0),
        paddingLeft: `calc(${theme.spacing(1)}px)`,
        width: '100%',

    }
  }));

function DMNeditorComponent(){
    const classes = useStyles();
    const dmnEditorContainer = useRef();
    const { filename } = useParams();
    const [ editor, setEditor] = useState();
    const [ fileName, setfileName] = useState('new-file');

    const handleChange = (event) => {
        setfileName(event.target.value);
    };

    const redoDMN = () => {
        editor.redo();
        console.log("model Saved");
    };

    const undoDMN = () => {
        editor.undo();
        console.log("model undo");
    };

    const downloadDMN = () => {
        editor.getContent().then(content => {
            const link = document.createElement('a');
            link.href = "data:text/plain;charset=utf-8,"+encodeURIComponent(content);
            link.setAttribute("download", fileName+".dmn");
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
        });

        console.log("model downloaded");
    };

    const downloadSVGDMN = () => {
        editor.getContent().then(content => {
            const link = document.createElement('a');
            link.href = "data:text/plain;charset=utf-8,"+encodeURIComponent(content);
            link.setAttribute("download", fileName+".svg");
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
        });
        console.log("model downloaded as svg");
    };

    useEffect(()=>{
        console.log('>',filename);
        let content = '';
        if(filename === "new-file"){
            content = Promise.resolve("")
        }else{
            content = dmnDataService.getData(filename)
                .then(response => {
                    console.log(response.headers);
                    return (response.data)
                })
                .catch(err => {
                    console.error("Error in fetching data from API")
                    console.error(err)
                    return ("")
                })
            setfileName(filename);
        }
        setEditor(DmnEditor.open({
            container: dmnEditorContainer.current,
            initialContent: content,
            readOnly: false,
        }))
    },[filename]);

    return (
        <div className={classes.root}>
            <AppBar position="static">
                <Toolbar>
                    <NavbarComponent classes={classes.menuButton}/>
                    <span className={classes.title}> DMN Editor </span>
                    <div className={classes.fileNameField}>
                        <InputBase placeholder="new-file" 
                            margin="dense" 
                            inputProps={{ disableunderline: "true" }} 
                            className={classes.fileNameInput}
                            value={fileName}
                            onChange={handleChange}/>
                    </div>
                    <UndoButton undoDMN={undoDMN}/>
                    <span>|</span>
                    <RedoButton redoDMN={redoDMN}/>
                    <DownloadButton downloadDMN={downloadDMN}/>
                    <Button onClick={downloadSVGDMN} color="inherit">Download as SVG</Button>
                </Toolbar>
            </AppBar>
            <div id="dmnEditor" ref={dmnEditorContainer}></div>
        </div>
        
    )
}

export default DMNeditorComponent;