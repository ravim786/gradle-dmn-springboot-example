import React, {useEffect, useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {AppBar,Toolbar, Typography, Container, Grid, Button} from '@material-ui/core';

import NavbarComponent from './NavbarComponent';

import dmnDataService from '../services/dmnService';

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 1,
    },
    content:{
      margin: theme.spacing(1)
    }
}));

const HomeComponent = () => {
    const classes = useStyles();
    const [data,setData]=useState([]);

    const handleClick = (event, index) => {
      console.log("fetch data from Server for ",data[index].filename);
      //history.push('/editors/dmn');
    }

    const getData = () => {
      dmnDataService.getAllServices().then((content)=>{
        console.log(content);
        setData(content);
      });
    }

    useEffect(()=>{
        getData();
    },[])

    return (
        <div>
            <AppBar position="static">
                <Toolbar>
                <NavbarComponent classes={classes.menuButton}/>
                <Typography variant="h6" className={classes.title}>
                    Hayagriva
                </Typography>
                </Toolbar>
            </AppBar>
            <Container>
              <Grid container direction="column" justify="center" alignItems="center" spacing={1} className={classes.content}>
              <p>Below are some of the examples created for understanding DMNs.</p>
              {
                data && data.length>0 && data.map((item, index)=>(
                  <Grid key={index} item xs={6} sm={3}>
                    {/* <Link to={"/editors/dmn/"+item.filename}><Button variant="contained" onClick={(e)=>handleClick(e,index)} color="secondary">{item.filename}</Button></Link> */}
                    <Button variant="contained"  href={"./#/editors/dmn/"+item.filename} onClick={(e)=>handleClick(e,index)} color="secondary">{item.filename}</Button>
                    {/* <Button key={index} variant="contained" onClick={(e)=>handleClick(e,index)} color="secondary">{item.filename}</Button> */}
                  </Grid>
                ))
              }
              </Grid>
            </Container>
      </div>
    );

};

export default HomeComponent;