import './App.css';
import {  Switch, Route } from "react-router-dom";
import HomeComponent from './components/HomeComponent';
import DMNeditorComponent from './components/editors/DMNeditorComponent';
import Error404 from './components/Error404';

function App() {
  return (
    <Switch>
      <Route exact path="/" component={HomeComponent}/>
      <Route path="/editors/dmn/:filename" component={DMNeditorComponent}/>
      <Route path="*" component={Error404}/>
    </Switch>
  );
}

export default App;
