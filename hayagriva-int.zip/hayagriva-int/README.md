# hayagriva

### Prerequisites required before hosting the springboot application

- Java 11, can be downloaded from [jdk.java.net](https://jdk.java.net/)

- maven, can be downloaded from [maven.apache.org](https://maven.apache.org/download.cgi)

- All other required tools will be installed in the development environment when we build the springboot application

### Steps for hosting springboot application

- Run the below command to install and build the application

  ` mvn clean install`

- Run below command to run the springboot application wiht react UI

  `mvn springboot:run`

### Steps to run react app locally without springboot application

- Run below command to install all the required npm packages.

  `npm install`

- Run below command to start the react application.

  `npm start`

### Swagger Documentation

path - http://localhost:8080/swagger-ui.html

### React UI

path - http://localhost:8080

### References

1. Kogito Editors, https://docs.jboss.org/kogito/release/latest/html_single/#proc-kogito-standalone-editors_kogito-creating-running
