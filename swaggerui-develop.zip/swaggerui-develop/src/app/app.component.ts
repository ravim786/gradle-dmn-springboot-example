import { Component } from '@angular/core';
import SwaggerClient from "swagger-client";
import { SwaggerResult } from './swagger-result';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {FormControl,
  FormGroup,
  FormBuilder,
  FormArray,
  Validators} from '@angular/forms';

  import * as _ from "lodash";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'swaggerclient';
  customTheme: string = 'bootstrap-4';
  Bootstrap:string ='form-control'
 
  constructor(private http: HttpClient) { }

  async schemaOptions(openapiURL){
    const a = await SwaggerClient.resolve({url: openapiURL});
    const s = a.spec.servers != null ? a.spec.servers : [];
    let endpoints = [];
    const b = a.spec.paths;
    for (const url in b) {
      try {
        const schema = b[url]["post"]["requestBody"]["content"]["application/json"]["schema"];
        if (schema != null) {
          endpoints.push({url : url, schema : schema});
        }
      } catch (error) {
        // the path url does not define any post for json, compatible with this app.
      }
    }
    const result: SwaggerResult = { endpoints: endpoints, servers: s};
    return result;
  }

  EMPTY_SELECTED = {url : "loading", schema: {
    "title": "Please enter openapi URL",
    "type": "object"
  }};
  schemas = [];
  openapiURL = "/openapi";
  selected: any  = this.EMPTY_SELECTED;
  requestPayload  = {};
  responsePayload: any  =  "(nothing yet.)";
  servers = [];
  selectedServer = "";
  key = new Date();
  fields = [];
  requestPayloadForm: FormGroup;
  isFormAvailable = false;
  formattedRequestPayload: any;
  formattedResponsePayload: any;


  ngOnInit(): void {
    this.handleOpenAPIURLChange = _.debounce(this.handleOpenAPIURLChange, 1000);
  }


  getFormControlsFields() {
    const formGroupFields = {};
    this.fields = [];
    for (var field of Object.keys(this.selected.schema.properties)) {
        console.log("Keys: "+ JSON.stringify(field));
        formGroupFields[field] = new FormControl("");
        this.fields.push(field);
    }
    console.log(JSON.stringify(this.fields));
    return formGroupFields;
}

buildForm() {
  this.isFormAvailable = true;
  const formGroupFields = this.getFormControlsFields();
  this.requestPayloadForm = new FormGroup(formGroupFields);
}

formatRequestPaylod(){
  this.formattedRequestPayload = JSON.stringify(this.requestPayload);
}



  handleChange(event) {
    this.selected = this.schemas.find(x => x.url === event.target.value);
    console.log('**Printing selected: '+ JSON.stringify(this.selected));
    //this.buildForm();
    this.requestPayload = {};
    this.formattedRequestPayload = JSON.stringify(this.requestPayload);;
    this.responsePayload = "(nothing yet.)";
    this.formattedResponsePayload = JSON.stringify(this.responsePayload);
  }

  handleOpenAPIURLChange(event) {
    const newURL = event.target.value.trim();
    this.openapiURL = newURL;
    console.log(this.openapiURL )

    this.refreshSchemasFromOpenapiURL(newURL);

  }



  refreshSchemasFromOpenapiURL(openapiURL) {
    this.schemaOptions(openapiURL).then(x => {
      this.schemas= x.endpoints;
      this.selected= x.endpoints?.length > 0 ? x.endpoints[0] : this.EMPTY_SELECTED;
      this.servers= x.servers;
      this.selectedServer = x.servers?.length > 0 ? x.servers[0].url : "";
      this.requestPayload = {};
      this.responsePayload = "(nothing yet.)";
    }).catch(err => {
      this.schemas= [];
      this.selected= { url : "Invalid_openAPI_url", schema: { "title": "Please enter a valid openapi URL", "type": "object" } };
    })

  }

  handleFormChange(a) {
    console.log('Inside form change: '+ JSON.stringify(a));
    this.requestPayload =  a;
    this.formatRequestPaylod();
  }

  handleServerChange(e) {
    this.selectedServer =  e.target.value;
  }

  overrideRequest(x) {
    console.log(x);
    this.requestPayload = x;
    this.key = new Date();
  }

  getCurrentRequestValue() {
    return this.requestPayload;
  }

  handleForm(a) {
    const formData = a;
    this.requestPayload= formData;
    const other_params = {
      headers: {
        'Accept': 'application/json, text/plain',
        'Content-Type': 'application/json'
    },
      body: JSON.stringify(formData),
      method: "POST",
      mode: "cors"
    };
    const destURL = this.selectedServer + this.selected.url;
    var headers = new HttpHeaders({'Accept': 'application/json, text/plain', 'Content-Type': 'application/json'});

    this.http.post(destURL, JSON.stringify(formData), {headers})
    .subscribe((data) => {
      console.log(data);
      this.responsePayload= data;
      this.formattedResponsePayload = JSON.stringify(this.responsePayload);
    });
  }


  onChangeTheme(event){
   

this.customTheme =event.target.value

this.Bootstrap = event.target.value=='bootstrap-4'?'form-control':'plain'

  }
}
