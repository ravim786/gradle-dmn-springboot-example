export interface SwaggerResult {
  endpoints: any;
  servers: any;
}
