package com.fanniemae.edms.dmn.jitrunner.api;

import com.fanniemae.edms.dmn.jitrunner.requests.JITDMNPayload;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class JITDMNResourceTest {
    private static ResourceLoader resourceLoader = new DefaultResourceLoader();
    private static String model;

    @Autowired
    WebTestClient webTestClient;

    @Autowired
    ObjectMapper objectMapper;

    @BeforeAll
    public static void setup() throws IOException {
        model = readDMNContentsAsString("/sum.dmn");
    }

    @Test
    public void runDMN() throws JsonProcessingException {
        Map<String, Object> context = objectMapper.readValue("{\"loan\": {\"baseLoanAmount\":450000,\"transaction\":{\"insuranceAmount\":52000}}}", Map.class);
        JITDMNPayload payload = new JITDMNPayload(model, context);
        webTestClient
                .post()
                .uri("/jitdmn")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(payload)
                .exchange()
                .expectStatus()
                .is2xxSuccessful()
                .expectBody(Map.class).value(resultMap -> {
                    Assertions.assertEquals(new BigDecimal("502000"), new BigDecimal(resultMap.get("sumFunction").toString()));
                    Assertions.assertEquals(new BigDecimal("502000"), new BigDecimal(resultMap.get("sumOperator").toString()));
                    Assertions.assertEquals(new BigDecimal("502000"), new BigDecimal(resultMap.get("nnSumFunction").toString()));
                });
    }

    @Test
    public void getDMNSchema() throws JsonProcessingException {
        webTestClient
                .post()
                .uri("/jitdmn/schema")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(model)
                .exchange()
                .expectStatus()
                .is2xxSuccessful()
                .expectBody(ObjectNode.class).value(objectNode -> {
            ObjectNode loanPropsNode = (ObjectNode) objectNode.get("definitions").get("Loan").get("properties");
            Assertions.assertNotNull(loanPropsNode);
            Assertions.assertEquals("number", ((JsonNode) loanPropsNode.get("baseLoanAmount").get("type")).textValue());
        });
    }

    @Test
    public void getDMNForm() throws JsonProcessingException {
        webTestClient
                .post()
                .uri("/jitdmn/schema/form")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(model)
                .exchange()
                .expectStatus()
                .is2xxSuccessful()
                .expectBody(ObjectNode.class).value(objectNode -> {
            ObjectNode loanPropsNode = (ObjectNode) objectNode.get("definitions").get("Loan").get("properties");
            Assertions.assertNotNull(loanPropsNode);
            Assertions.assertEquals("number", ((JsonNode) loanPropsNode.get("baseLoanAmount").get("type")).textValue());
        });
    }

    @Test
    public void validateDMN() throws JsonProcessingException {
        webTestClient
                .post()
                .uri("/jitdmn/validate")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(model)
                .exchange()
                .expectStatus()
                .is2xxSuccessful()
                .expectBody(List.class).value(messages -> {
            Assertions.assertEquals(0, messages.size());
        });
    }

    private static  String readDMNContentsAsString(String dmnfile) throws IOException {
        Resource resource = resourceLoader.getResource(dmnfile);
        InputStream fileStream = resource.getInputStream();
        return IOUtils.toString(fileStream, StandardCharsets.UTF_8);
    }
}
