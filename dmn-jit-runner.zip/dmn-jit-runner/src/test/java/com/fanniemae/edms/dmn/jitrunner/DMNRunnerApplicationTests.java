package com.fanniemae.edms.dmn.jitrunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DMNRunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
