package com.fanniemae.edms.dmn.jitrunner.service;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.kie.kogito.dmn.rest.KogitoDMNMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

@SpringBootTest
public class DMNValidationServiceTest {
    private static String model;

    private static ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Autowired
    private DMNValidationService dmnValidationService;

    @BeforeAll
    public static void setup() throws IOException {
        model = readDMNContentsAsString("/sum.dmn");
    }

    @Test
    public void testModelSchema() {
        List<KogitoDMNMessage> messages = dmnValidationService.validate(model);
        Assertions.assertEquals(0, messages.size());
    }

    private static String readDMNContentsAsString(String dmnfile) throws IOException {
        Resource resource = resourceLoader.getResource(dmnfile);
        InputStream fileStream = resource.getInputStream();
        return IOUtils.toString(fileStream, StandardCharsets.UTF_8);
    }
}
