package com.fanniemae.edms.dmn.jitrunner.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@SpringBootTest
public class DMNSchemaServiceTest {
    private static String model;

    private static ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Autowired
    private DMNSchemaService dmnSchemaService;

    @BeforeAll
    public static void setup() throws IOException {
        model = readDMNContentsAsString("/sum.dmn");
    }

    @Test
    public void testModelSchema() {
        ObjectNode objectNode = dmnSchemaService.getSchema(model);

        ObjectNode loanPropsNode = (ObjectNode) objectNode.get("definitions").get("Loan").get("properties");
        Assertions.assertNotNull(loanPropsNode);
        Assertions.assertEquals("number", ((JsonNode) loanPropsNode.get("baseLoanAmount").get("type")).textValue());
    }

    @Test
    public void testModelForm() {
        ObjectNode objectNode = dmnSchemaService.getPayloadSchema(model);

        ObjectNode loanPropsNode = (ObjectNode) objectNode.get("definitions").get("Loan").get("properties");
        Assertions.assertNotNull(loanPropsNode);
        Assertions.assertEquals("number", ((JsonNode) loanPropsNode.get("baseLoanAmount").get("type")).textValue());
    }

    private static String readDMNContentsAsString(String dmnfile) throws IOException {
        Resource resource = resourceLoader.getResource(dmnfile);
        InputStream fileStream = resource.getInputStream();
        return IOUtils.toString(fileStream, StandardCharsets.UTF_8);
    }
}
