package com.fanniemae.edms.dmn.jitrunner.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.kie.kogito.dmn.rest.KogitoDMNResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@SpringBootTest
public class DMNExecutorServiceTest {
    private static String model;

    private static ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Autowired
    private DMNExecutorService dmnExecutorService;

    @Autowired
    ObjectMapper objectMapper;

    @BeforeAll
    public static void setup() throws IOException {
        model = readDMNContentsAsString("/sum.dmn");
    }

    @Test
    public void testModelEvaluation() throws JSONException, JsonProcessingException {
        Map<String, Object> context = objectMapper.readValue("{\"loan\": {\"baseLoanAmount\":450000,\"transaction\":{\"insuranceAmount\":52000}}}", Map.class);
        KogitoDMNResult dmnResult = dmnExecutorService.evaluateModel(model, context);

        Assertions.assertEquals("sum", dmnResult.getModelName());
        Assertions.assertEquals("https://kiegroup.org/dmn/_D5C09393-48EC-41FB-AA30-ED6C0D2F5987", dmnResult.getNamespace());
        Assertions.assertTrue(dmnResult.getMessages().isEmpty());

        Assertions.assertEquals(new BigDecimal("502000"), dmnResult.getDecisionResultByName("sumFunction").getResult());
        Assertions.assertEquals(new BigDecimal("502000"), dmnResult.getDecisionResultByName("sumOperator").getResult());
        Assertions.assertEquals(new BigDecimal("502000"), dmnResult.getDecisionResultByName("nnSumFunction").getResult());

    }

    private static String readDMNContentsAsString(String dmnfile) throws IOException {
        Resource resource = resourceLoader.getResource(dmnfile);
        InputStream fileStream = resource.getInputStream();
        return IOUtils.toString(fileStream, StandardCharsets.UTF_8);
    }
}
