package com.fanniemae.edms.dmn.jitrunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DMNRunnerApplication {
	public static void main(String[] args) {
		SpringApplication.run(DMNRunnerApplication.class, args);
	}
}
