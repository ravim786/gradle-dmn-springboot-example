package com.fanniemae.edms.dmn.jitrunner.service.impl;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fanniemae.edms.dmn.jitrunner.service.DMNSchemaService;
import io.smallrye.openapi.runtime.io.schema.SchemaWriter;
import lombok.NoArgsConstructor;
import org.eclipse.microprofile.openapi.OASFactory;
import org.eclipse.microprofile.openapi.models.OpenAPI;
import org.eclipse.microprofile.openapi.models.media.Schema;
import org.eclipse.microprofile.openapi.spi.OASFactoryResolver;
import org.kie.api.io.Resource;
import org.kie.dmn.api.core.DMNModel;
import org.kie.dmn.api.core.DMNRuntime;
import org.kie.dmn.api.core.DMNType;
import org.kie.dmn.core.internal.utils.DMNRuntimeBuilder;
import org.kie.dmn.openapi.DMNOASGeneratorFactory;
import org.kie.dmn.openapi.model.DMNOASResult;
import org.kie.internal.io.ResourceFactory;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.util.Collections;
import java.util.Map;

@Service("dmnSchemaService")
@NoArgsConstructor
public class DMNSchemaServiceImpl implements DMNSchemaService {
    // trick for resolver/implementation for Native Implementation
    static final OpenAPI x;
    static {
        OASFactoryResolver.instance();
        x = OASFactory.createObject(OpenAPI.class);
    }

    private static DMNModel modelFromXML(String modelXML) {
        Resource modelResource = ResourceFactory.newReaderResource(new StringReader(modelXML), "UTF-8");
        DMNRuntime dmnRuntime = DMNRuntimeBuilder.fromDefaults().buildConfiguration().fromResources(Collections.singletonList(modelResource)).getOrElseThrow(RuntimeException::new);
        return dmnRuntime.getModels().get(0);
    }

    private DMNOASResult generateModelSchema(DMNModel dmnModel) {
        return DMNOASGeneratorFactory.generator(Collections.singletonList(dmnModel)).build();
    }

    @Override
    public ObjectNode getSchema(String modelXML) {
        DMNModel dmnModel = modelFromXML(modelXML);
        DMNOASResult oasResult = generateModelSchema(dmnModel);
        ObjectNode jsNode = oasResult.getJsonSchemaNode();

        DMNType is = oasResult.lookupIOSetsByModel(dmnModel).getInputSet();
        String isRef = oasResult.getNamingPolicy().getRef(is);
        Schema schema = OASFactory.createObject(Schema.class).type(Schema.SchemaType.OBJECT);
        schema.addProperty("context", OASFactory.createObject(Schema.class).type(Schema.SchemaType.OBJECT).ref(isRef));
        schema.addProperty("model", OASFactory.createObject(Schema.class).type(Schema.SchemaType.STRING));
        ObjectNode schemasNode = jsNode.putObject("properties");
        for (Map.Entry<String, Schema> entry : schema.getProperties().entrySet()) {
            SchemaWriter.writeSchema(schemasNode, entry.getValue(), entry.getKey());
        }
        jsNode.put("type", "object");
        jsNode.putArray("required").add("context").add("model");
        return jsNode;
    }

    @Override
    public ObjectNode getPayloadSchema(String modelXML) {
        DMNModel dmnModel = modelFromXML(modelXML);
        DMNOASResult oasResult = generateModelSchema(dmnModel);
        ObjectNode jsNode = oasResult.getJsonSchemaNode();

        DMNType is = oasResult.lookupIOSetsByModel(dmnModel).getInputSet();
        String isRef = oasResult.getNamingPolicy().getRef(is);
        jsNode.put("$ref", isRef);

        return jsNode;
    }
}
