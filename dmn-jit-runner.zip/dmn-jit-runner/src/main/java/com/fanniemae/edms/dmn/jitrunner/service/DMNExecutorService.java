package com.fanniemae.edms.dmn.jitrunner.service;

import java.util.Map;

import org.kie.kogito.dmn.rest.KogitoDMNResult;

public interface DMNExecutorService {
    KogitoDMNResult evaluateModel(String modelXML, Map<String, Object> context);
}
