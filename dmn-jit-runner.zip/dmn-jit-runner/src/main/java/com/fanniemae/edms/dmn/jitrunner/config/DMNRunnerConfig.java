package com.fanniemae.edms.dmn.jitrunner.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

@ComponentScan("com.fanniemae.edms.dmn.jitrunner")
public class DMNRunnerConfig {

    @Bean
    public ObjectMapper objectMapper(Jackson2ObjectMapperBuilder builder) {
        return builder.build().registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule())
                .registerModule(new com.fasterxml.jackson.databind.module.SimpleModule().addSerializer(
                        org.kie.dmn.feel.lang.types.impl.ComparablePeriod.class,
                        new org.kie.kogito.dmn.rest.DMNFEELComparablePeriodSerializer()))
                .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DURATIONS_AS_TIMESTAMPS);
    }
}
