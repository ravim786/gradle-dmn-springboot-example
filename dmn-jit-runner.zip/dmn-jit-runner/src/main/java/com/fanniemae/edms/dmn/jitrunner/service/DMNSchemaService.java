package com.fanniemae.edms.dmn.jitrunner.service;

import com.fasterxml.jackson.databind.node.ObjectNode;

public interface DMNSchemaService {
    ObjectNode getSchema(String modelXML);
    ObjectNode getPayloadSchema(String modelXML);
}
