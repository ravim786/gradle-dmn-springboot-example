package com.fanniemae.edms.dmn.jitrunner.service;

import org.kie.kogito.dmn.rest.KogitoDMNMessage;

import java.util.List;

public interface DMNValidationService {
    List<KogitoDMNMessage> validate(String modelXML);
}
