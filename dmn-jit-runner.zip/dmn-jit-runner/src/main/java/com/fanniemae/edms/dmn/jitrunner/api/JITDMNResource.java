package com.fanniemae.edms.dmn.jitrunner.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fanniemae.edms.dmn.jitrunner.requests.JITDMNPayload;
import com.fanniemae.edms.dmn.jitrunner.service.DMNExecutorService;
import com.fanniemae.edms.dmn.jitrunner.service.DMNSchemaService;
import com.fanniemae.edms.dmn.jitrunner.service.DMNValidationService;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.kie.dmn.core.internal.utils.MarshallingStubUtils;
import org.kie.kogito.dmn.rest.KogitoDMNMessage;
import org.kie.kogito.dmn.rest.KogitoDMNResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/jitdmn")
public class JITDMNResource {

    @Autowired
    DMNExecutorService dmnExecutorService;
    @Autowired
    DMNSchemaService dmnSchemaService;
    @Autowired
    DMNValidationService dmnValidationService;

    @RequestMapping(method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Mono<Map<String, Object>>> jitdmn(@RequestBody JITDMNPayload payload) {
        KogitoDMNResult evaluateAll = dmnExecutorService.evaluateModel(payload.getModel(), payload.getContext());
        Map<String, Object> restResulk = new HashMap<>();
        for (Entry<String, Object> kv : evaluateAll.getContext().getAll().entrySet()) {
            restResulk.put(kv.getKey(), MarshallingStubUtils.stubDMNResult(kv.getValue(), String::valueOf));
        }
        return new ResponseEntity<>(Mono.just(restResulk), HttpStatus.OK);
    }

    @RequestMapping(value = "/dmnresult", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Mono<KogitoDMNResult>> jitdmnResult(@RequestBody JITDMNPayload payload) {
        KogitoDMNResult dmnResult = dmnExecutorService.evaluateModel(payload.getModel(), payload.getContext());
        return new ResponseEntity<>(Mono.just(dmnResult), HttpStatus.OK);
    }

    @RequestMapping(value = "/schema", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Mono<ObjectNode>> schema(@RequestBody String payload) {
        ObjectNode jsNode = dmnSchemaService.getSchema(payload);
        return new ResponseEntity<>(Mono.just(jsNode), HttpStatus.OK);
    }

    @RequestMapping(value = "/schema/form", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Mono<ObjectNode>> form(@RequestBody String payload) {
        ObjectNode jsNode = dmnSchemaService.getPayloadSchema(payload);
        return new ResponseEntity<>(Mono.just(jsNode), HttpStatus.OK);
    }

    @RequestMapping(value = "/validate", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Mono<List<KogitoDMNMessage>>> validate(@RequestBody String payload) {
        List<KogitoDMNMessage> result = dmnValidationService.validate(payload);
        return new ResponseEntity<>(Mono.just(result), HttpStatus.OK);
    }
}