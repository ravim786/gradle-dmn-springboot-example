package com.fanniemae.edms.dmn.jitrunner.service.impl;

import java.util.Map;

import com.fanniemae.edms.dmn.jitrunner.service.DMNExecutorService;
import com.fanniemae.edms.dmn.jitrunner.utils.DMNEvaluator;
import lombok.NoArgsConstructor;
import org.kie.dmn.api.core.DMNResult;
import org.kie.kogito.dmn.rest.KogitoDMNResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("dmnExecutorService")
@NoArgsConstructor
public class DMNExecutorServiceImpl implements DMNExecutorService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DMNExecutorServiceImpl.class);

    @Override
    public KogitoDMNResult evaluateModel(String modelXML, Map<String, Object> context) {
        DMNEvaluator dmnEvaluator = DMNEvaluator.fromXML(modelXML);
        DMNResult dmnResult = dmnEvaluator.evaluate(context);
        return new KogitoDMNResult(dmnEvaluator.getNamespace(), dmnEvaluator.getName(), dmnResult);
    }

}
