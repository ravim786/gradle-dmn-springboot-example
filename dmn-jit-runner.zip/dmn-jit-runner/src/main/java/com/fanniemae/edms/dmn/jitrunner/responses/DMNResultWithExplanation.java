package com.fanniemae.edms.dmn.jitrunner.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.kie.kogito.dmn.rest.KogitoDMNResult;

@Data
@NoArgsConstructor
public class DMNResultWithExplanation {
    @JsonProperty("dmnResult")
    public KogitoDMNResult dmnResult;
}
