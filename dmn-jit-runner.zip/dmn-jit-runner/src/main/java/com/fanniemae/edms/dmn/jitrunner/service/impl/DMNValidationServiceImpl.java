package com.fanniemae.edms.dmn.jitrunner.service.impl;

import com.fanniemae.edms.dmn.jitrunner.service.DMNValidationService;
import lombok.NoArgsConstructor;
import org.kie.dmn.api.core.DMNMessage;
import org.kie.dmn.core.compiler.profiles.ExtendedDMNProfile;
import org.kie.dmn.validation.DMNValidator;
import org.kie.dmn.validation.DMNValidatorFactory;
import org.kie.kogito.dmn.rest.KogitoDMNMessage;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service("dmnValidationService")
@NoArgsConstructor
public class DMNValidationServiceImpl implements DMNValidationService {

    // trick for resolver/implementation for Native Implementation
    static final DMNValidator validator = DMNValidatorFactory.newValidator(Arrays.asList(new ExtendedDMNProfile()));

    @Override
    public List<KogitoDMNMessage> validate(String modelXML) {
        List<DMNMessage> validate =
                validator.validate(new StringReader(modelXML), DMNValidator.Validation.VALIDATE_SCHEMA, DMNValidator.Validation.VALIDATE_MODEL, DMNValidator.Validation.VALIDATE_COMPILATION, DMNValidator.Validation.ANALYZE_DECISION_TABLE);
        return validate.stream().map(KogitoDMNMessage::of).collect(Collectors.toList());
    }
}
