package org.kie.kogito.dmn.api.core;

import org.kie.dmn.api.core.DMNMessage;

import java.util.List;

public interface DMNMessageContainer {
    List<DMNMessage> getMessages();

    List<DMNMessage> getMessages(DMNMessage.Severity... var1);

    boolean hasErrors();
}
