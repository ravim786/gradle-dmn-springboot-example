package org.kie.kogito.dmn.config;

import org.kie.dmn.api.core.event.DMNRuntimeEventListener;
import org.kie.kogito.decision.DecisionEventListenerConfig;

import java.util.ArrayList;
import java.util.List;

public class CachedDecisionEventListenerConfig implements DecisionEventListenerConfig {

    private final List<DMNRuntimeEventListener> listeners;

    public CachedDecisionEventListenerConfig() {
        listeners = new ArrayList<>();
    }

    public CachedDecisionEventListenerConfig(List<DMNRuntimeEventListener> listeners) {
        this.listeners = listeners;
    }

    public CachedDecisionEventListenerConfig register(DMNRuntimeEventListener listener) {
        listeners.add(listener);
        return this;
    }

    @Override
    public List<DMNRuntimeEventListener> listeners() {
        return listeners;
    }

}
