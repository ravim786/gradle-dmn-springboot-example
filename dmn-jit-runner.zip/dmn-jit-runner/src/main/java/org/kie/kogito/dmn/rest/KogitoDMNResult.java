package org.kie.kogito.dmn.rest;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.kie.dmn.api.core.DMNContext;
import org.kie.dmn.api.core.DMNDecisionResult;
import org.kie.dmn.api.core.DMNMessage;
import org.kie.dmn.api.core.DMNResult;
import org.kie.dmn.core.internal.utils.MapBackedDMNContext;
import org.kie.dmn.core.internal.utils.MarshallingStubUtils;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class KogitoDMNResult implements Serializable, DMNResult {
    private String namespace;
    private String modelName;
    private Map<String, Object> dmnContext = new HashMap();
    private List<KogitoDMNMessage> messages = new ArrayList();
    private Map<String, KogitoDMNDecisionResult> decisionResults = new HashMap();

    public KogitoDMNResult() {
    }

    public KogitoDMNResult(String namespace, String modelName, DMNResult dmnResult) {
        this.namespace = namespace;
        this.modelName = modelName;
        this.setDmnContext(dmnResult.getContext().getAll());
        this.setMessages(dmnResult.getMessages());
        this.setDecisionResults(dmnResult.getDecisionResults());
    }

    public String getNamespace() {
        return this.namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getModelName() {
        return this.modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public Map<String, Object> getDmnContext() {
        return this.dmnContext;
    }

    public void setDmnContext(Map<String, Object> dmnContext) {
        this.dmnContext = new HashMap();
        Iterator var2 = dmnContext.entrySet().iterator();

        while(var2.hasNext()) {
            Map.Entry<String, Object> kv = (Map.Entry)var2.next();
            this.dmnContext.put((String)kv.getKey(), MarshallingStubUtils.stubDMNResult(kv.getValue(), String::valueOf));
        }

    }

    public void setMessages(List<DMNMessage> messages) {
        this.messages = new ArrayList();
        Iterator var2 = messages.iterator();

        while(var2.hasNext()) {
            DMNMessage m = (DMNMessage)var2.next();
            this.messages.add(KogitoDMNMessage.of(m));
        }

    }

    public void setDecisionResults(List<? extends DMNDecisionResult> decisionResults) {
        this.decisionResults = new HashMap();
        Iterator var2 = decisionResults.iterator();

        while(var2.hasNext()) {
            DMNDecisionResult dr = (DMNDecisionResult)var2.next();
            this.decisionResults.put(dr.getDecisionId(), KogitoDMNDecisionResult.of(dr));
        }

    }

    @JsonIgnore
    public DMNContext getContext() {
        return MapBackedDMNContext.of(this.dmnContext);
    }

    public List getMessages() {
        return this.messages;
    }

    public List<DMNMessage> getMessages(DMNMessage.Severity... sevs) {
        return (List)this.messages.stream().filter((m) -> {
            return Arrays.asList(sevs).stream().anyMatch((f) -> {
                return f.equals(m.getSeverity());
            });
        }).collect(Collectors.toList());
    }

    public boolean hasErrors() {
        return this.messages.stream().anyMatch((m) -> {
            return DMNMessage.Severity.ERROR.equals(m.getSeverity());
        });
    }

    public List<DMNDecisionResult> getDecisionResults() {
        return new ArrayList(this.decisionResults.values());
    }

    public DMNDecisionResult getDecisionResultByName(String name) {
        return (DMNDecisionResult)this.decisionResults.values().stream().filter((dr) -> {
            return dr.getDecisionName().equals(name);
        }).findFirst().orElseThrow(() -> {
            return new RuntimeException("Unknown decision result name.");
        });
    }

    public DMNDecisionResult getDecisionResultById(String id) {
        return (DMNDecisionResult)this.decisionResults.get(id);
    }

    public String toString() {
        return "KogitoDMNResult [" + "namespace=" + this.namespace + ", modelName=" + this.modelName + ", dmnContext=" + this.dmnContext + ", messages=" + this.messages + ", decisionResults=" + this.decisionResults + "]";
    }
}
