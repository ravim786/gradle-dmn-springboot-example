package org.kie.kogito.dmn.rest;

import org.kie.dmn.api.core.DMNDecisionResult;
import org.kie.dmn.api.core.DMNMessage;
import org.kie.dmn.core.internal.utils.MarshallingStubUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class KogitoDMNDecisionResult implements Serializable, DMNDecisionResult {
    private String decisionId;
    private String decisionName;
    private Object result;
    private List<KogitoDMNMessage> messages = new ArrayList();
    private DecisionEvaluationStatus status;

    public KogitoDMNDecisionResult() {
    }

    public static KogitoDMNDecisionResult of(DMNDecisionResult value) {
        KogitoDMNDecisionResult res = new KogitoDMNDecisionResult();
        res.decisionId = value.getDecisionId();
        res.decisionName = value.getDecisionName();
        res.setResult(value.getResult());
        res.setMessages(value.getMessages());
        res.status = value.getEvaluationStatus();
        return res;
    }

    public String getDecisionId() {
        return this.decisionId;
    }

    public void setDecisionId(String decisionId) {
        this.decisionId = decisionId;
    }

    public String getDecisionName() {
        return this.decisionName;
    }

    public void setDecisionName(String decisionName) {
        this.decisionName = decisionName;
    }

    public DecisionEvaluationStatus getEvaluationStatus() {
        return this.status;
    }

    public void setEvaluationStatus(DecisionEvaluationStatus status) {
        this.status = status;
    }

    public Object getResult() {
        return this.result;
    }

    public void setResult(Object result) {
        this.result = MarshallingStubUtils.stubDMNResult(result, String::valueOf);
    }

    public List getMessages() {
        return this.messages;
    }

    public void setMessages(List<DMNMessage> messages) {
        this.messages = new ArrayList();
        Iterator var2 = messages.iterator();

        while(var2.hasNext()) {
            DMNMessage m = (DMNMessage)var2.next();
            this.messages.add(KogitoDMNMessage.of(m));
        }

    }

    public boolean hasErrors() {
        return this.messages != null && this.messages.stream().anyMatch((m) -> {
            return m.getSeverity() == DMNMessage.Severity.ERROR;
        });
    }
}

