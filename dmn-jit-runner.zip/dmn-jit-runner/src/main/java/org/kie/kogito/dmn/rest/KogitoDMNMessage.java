package org.kie.kogito.dmn.rest;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.kie.dmn.api.core.DMNMessage;
import org.kie.dmn.api.core.DMNMessageType;
import org.kie.dmn.api.feel.runtime.events.FEELEvent;
import org.kie.internal.builder.InternalMessage;

import java.io.Serializable;

public class KogitoDMNMessage implements Serializable, DMNMessage {
    private KogitoDMNMessage.DMNMessageSeverityKS severity;
    private String message;
    private DMNMessageType messageType;
    private String sourceId;

    public KogitoDMNMessage() {
    }

    public static KogitoDMNMessage of(DMNMessage value) {
        KogitoDMNMessage res = new KogitoDMNMessage();
        res.severity = KogitoDMNMessage.DMNMessageSeverityKS.of(value.getSeverity());
        res.message = value.getMessage();
        res.messageType = value.getMessageType();
        res.sourceId = value.getSourceId();
        return res;
    }

    public Severity getSeverity() {
        return this.severity.asSeverity();
    }

    public String getMessage() {
        return this.message;
    }

    public DMNMessageType getMessageType() {
        return this.messageType;
    }

    public String getSourceId() {
        return this.sourceId;
    }

    @JsonIgnore
    public Throwable getException() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public FEELEvent getFeelEvent() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public Object getSourceReference() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public String getKieBaseName() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public InternalMessage setKieBaseName(String kieBaseName) {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public long getId() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public String getPath() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public int getLine() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public int getColumn() {
        throw new UnsupportedOperationException();
    }

    public Level getLevel() {
        switch(this.severity) {
            case ERROR:
                return Level.ERROR;
            case INFO:
                return Level.INFO;
            case WARN:
                return Level.WARNING;
            default:
                return Level.ERROR;
        }
    }

    @JsonIgnore
    public String getText() {
        throw new UnsupportedOperationException();
    }

    public static enum DMNMessageSeverityKS {
        INFO,
        WARN,
        ERROR;

        private DMNMessageSeverityKS() {
        }

        public static KogitoDMNMessage.DMNMessageSeverityKS of(Severity value) {
            switch(value) {
                case ERROR:
                    return ERROR;
                case INFO:
                    return INFO;
                case TRACE:
                    return INFO;
                case WARN:
                    return WARN;
                default:
                    return ERROR;
            }
        }

        public Severity asSeverity() {
            switch(this) {
                case ERROR:
                    return Severity.ERROR;
                case INFO:
                    return Severity.INFO;
                case WARN:
                    return Severity.WARN;
                default:
                    return Severity.ERROR;
            }
        }
    }
}

