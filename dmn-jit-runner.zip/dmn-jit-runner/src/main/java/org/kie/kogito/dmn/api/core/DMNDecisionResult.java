package org.kie.kogito.dmn.api.core;

import org.kie.dmn.api.core.DMNMessage;

import java.util.List;

public interface DMNDecisionResult {
    String getDecisionId();

    String getDecisionName();

    org.kie.dmn.api.core.DMNDecisionResult.DecisionEvaluationStatus getEvaluationStatus();

    Object getResult();

    List<DMNMessage> getMessages();

    boolean hasErrors();

    public static enum DecisionEvaluationStatus {
        NOT_EVALUATED,
        EVALUATING,
        SUCCEEDED,
        SKIPPED,
        FAILED;

        private DecisionEvaluationStatus() {
        }
    }
}

