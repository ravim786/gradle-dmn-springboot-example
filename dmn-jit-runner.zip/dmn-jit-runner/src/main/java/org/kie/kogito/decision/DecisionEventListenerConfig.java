package org.kie.kogito.decision;

import org.kie.dmn.api.core.event.DMNRuntimeEventListener;

import java.util.List;

public interface DecisionEventListenerConfig {
    List<DMNRuntimeEventListener> listeners();
}
