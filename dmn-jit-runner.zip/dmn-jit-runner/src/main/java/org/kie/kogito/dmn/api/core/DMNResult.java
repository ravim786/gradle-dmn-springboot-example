package org.kie.kogito.dmn.api.core;

import org.kie.dmn.api.core.DMNContext;
import org.kie.dmn.api.core.DMNDecisionResult;
import org.kie.dmn.api.core.DMNMessageContainer;

import java.util.List;

public interface DMNResult extends DMNMessageContainer {
    DMNContext getContext();

    List<DMNDecisionResult> getDecisionResults();

    DMNDecisionResult getDecisionResultByName(String var1);

    DMNDecisionResult getDecisionResultById(String var1);
}